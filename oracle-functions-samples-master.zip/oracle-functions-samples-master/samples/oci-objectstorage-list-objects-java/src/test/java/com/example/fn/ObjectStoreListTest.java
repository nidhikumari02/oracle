/*
** ObjectStoreListTest version 1.0.
**
** Copyright (c) 2019 Oracle, Inc.  All rights reserved.
** Licensed under the Universal Permissive License v 1.0 as shown at https://oss.oracle.com/licenses/upl.
*/

package com.example.fn;

import com.fnproject.fn.testing.*;
import org.junit.*;

import static org.junit.Assert.*;

public class ObjectStoreListTest {

    @Rule
    public final FnTestingRule testing = FnTestingRule.createDefault();

    @Test
    public void shouldReturnGreeting() {
//        testing.givenEvent().enqueue();
//        testing.thenRun(HelloFunction.class, "handleRequest");
//
//        FnResult result = testing.getOnlyResult();
//        assertEquals("Hello, world!", result.getBodyAsString());
    }

}
