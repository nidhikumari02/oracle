# Basic Observability Guidance

This example shows how you can get basic observability using out-of-the-box service metrics and alarms for
* [Functions](functions.md)
* [Notifications Service](notifications.md)
* [Service Connector Hub](service-connector-hub.md)